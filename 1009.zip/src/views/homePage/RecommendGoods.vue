<template>
    <div>
        这是推荐商品
    </div>
</template>
<script>
    export default {}
</script>