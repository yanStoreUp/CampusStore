<template>
    <div>
        这是热门商品
    </div>
</template>
<script>
    export default {}
</script>