<template>
  <div>
    <mt-header fixed title="固定在顶部"></mt-header>
  </div>
</template>

<script>
export default {
  
}
</script>

<style lang="less">
  
</style>